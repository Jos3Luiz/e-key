#!/bin/sh
serverless deploy --stage dev
